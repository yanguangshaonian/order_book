/**
 * Xilinx Vitis 环境类型定义
 */

#ifndef __XV_DEFINE_H__
#define __XV_DEFINE_H__

#define DWIDTH 4096

#ifdef AP_INT_MAX_W
#undef AP_INT_MAX_W 
#endif
#define AP_INT_MAX_W 4096

#include "ap_int.h"

#endif
