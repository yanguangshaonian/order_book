# L2测试数据

## 文件名格式

```t
AX_sbe_[SE]_[SecurityID].log
```

如：

```t
AX_sbe_szse_000001.log
AX_sbe_szse_300750.log
AX_sbe_sse_600519.log
```

## 文件内容

参见[L2行情消息细节](/doc/msgTypes.md)之历史数据格式。
