from tool.test.test_tdx import *


if __name__== '__main__':
    tdx_vipdoc='E:/work/99_s3/tdx/vipdoc'

    test_TdxDailyBarReader(tdx_vipdoc)
